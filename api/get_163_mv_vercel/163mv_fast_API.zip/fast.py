# coding:utf-8
import uvicorn
from fastapi import FastAPI
import logger as lg
import get_data as gd

app = FastAPI()


@app.get("/")
def main(vid: int = None):
    lg.logger.info('-' * 20 + '开始记录日志' + '-' * 20)
    if not isinstance(vid, int):
        lg.logger.error('params must be a int')
        return {'message': 'Fast API'}
    params_data = gd.get_video_link(vid)
    return params_data


if __name__ == "__main__":
    uvicorn.run("fast:app", host="127.0.0.1", port=61, log_level="info")
